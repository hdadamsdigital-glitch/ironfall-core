# LLC Ownership Standard — IRONFALL
Product: IRONFALL
Brand / Legal Ownership Framework: HD Adams Digital® LLC
Copyright: © 2026 HD Adams Digital®. All rights reserved.
All IRONFALL source code, game design, systems, documentation, branding, and related IP are to be treated as company-owned LLC assets unless a signed agreement expressly states otherwise.
