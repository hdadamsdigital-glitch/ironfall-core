package com.hdadamsdigital.ironfall
import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.MotionEvent
import android.view.View
class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(IronfallView()) }
 private inner class IronfallView : View(this@MainActivity) {
  private val p=Paint(Paint.ANTI_ALIAS_FLAG); private var x=0f; private var y=0f
  override fun onDraw(c:Canvas){ c.drawColor(Color.rgb(12,15,20)); p.color=Color.WHITE; p.textSize=64f; c.drawText("IRONFALL",60f,90f,p); p.textSize=26f; c.drawText("Android prototype • HD Adams Digital®",60f,135f,p); p.textSize=22f; c.drawText("Touch to move",60f,175f,p); p.color=Color.rgb(90,160,255); c.drawCircle(if(x==0f)width/2f else x,if(y==0f)height/2f else y,36f,p) }
  override fun onTouchEvent(e:MotionEvent):Boolean { if(e.action==MotionEvent.ACTION_DOWN||e.action==MotionEvent.ACTION_MOVE){x=e.x;y=e.y;invalidate()}; return true }
 }
}
