# Editable Android Studio Package — IRONFALL
Open this folder directly in Android Studio. The Android source is intentionally exposed and editable.
This is the starting Android prototype foundation for IRONFALL, not the finished multiplayer battle-royale game.
© 2026 HD Adams Digital®. All rights reserved.
